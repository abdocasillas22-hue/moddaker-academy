# دليل رفع تطبيق مدكر أكاديمي

## ⚠️ ملاحظة مهمة عن Netlify
Netlify تدعم فقط المواقع الثابتة (HTML/CSS/JS). تطبيقنا يحتاج سيرفر Node.js وقاعدة بيانات PostgreSQL، لذلك يجب الرفع على منصة تدعم Node.js مثل:
- **Railway** (أسهل — موصى به)
- **Render**
- **Fly.io**

---

## الطريقة الأسهل: Railway

### الخطوات:
1. اذهب إلى https://railway.app وأنشئ حساب مجاني
2. اضغط "New Project" → "Deploy from GitHub repo"
3. ارفع الملفات على GitHub أولاً (أو استخدم Railway CLI)
4. سيكتشف Railway ملف `Dockerfile` تلقائياً ويبني التطبيق
5. أضف قاعدة بيانات PostgreSQL من داخل Railway (New → Database → PostgreSQL)
6. اضبط المتغيرات (Variables) التالية:

```
DATABASE_URL         = (يأتي تلقائياً من Railway PostgreSQL)
CLERK_SECRET_KEY     = sk_live_... (من لوحة Clerk)
CLERK_PUBLISHABLE_KEY = pk_live_... (من لوحة Clerk)
VITE_CLERK_PUBLISHABLE_KEY = pk_live_... (نفس الأعلى)
SESSION_SECRET       = أي نص طويل عشوائي
```

### متغيرات واتساب (اختيارية):
```
TWILIO_ACCOUNT_SID      = من لوحة Twilio
TWILIO_AUTH_TOKEN       = من لوحة Twilio
TWILIO_WHATSAPP_FROM    = whatsapp:+14155238886
ADMIN_WHATSAPP_NUMBER   = 01105448596
```

---

## البيانات تُحفظ تلقائياً ✅
- كل الرواتب، الحصص، الطلاب، المعلمين محفوظة في PostgreSQL
- البيانات لا تُمسح عند إعادة تشغيل التطبيق
- Railway يوفر persistent database مجانية لـ 500MB

---

## بناء التطبيق يدوياً (اختياري)

```bash
# تثبيت الحزم
pnpm install

# بناء قاعدة البيانات
pnpm --filter @workspace/db run push

# تشغيل التطبيق
pnpm --filter @workspace/api-server run dev
pnpm --filter @workspace/moddaker-academy run dev
```
