import schedule from "node-schedule";
import twilio from "twilio";
import { db, schedulesTable, studentsTable, teachersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { logger } from "./logger";

const dayNamesEn = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

function getTodayName(): string {
  return dayNamesEn[new Date().getDay()];
}

function toE164Egypt(phone: string): string {
  const cleaned = phone.replace(/\s+/g, "");
  if (cleaned.startsWith("+")) return cleaned;
  if (cleaned.startsWith("00")) return `+${cleaned.slice(2)}`;
  if (cleaned.startsWith("0")) return `+20${cleaned.slice(1)}`;
  return `+20${cleaned}`;
}

async function checkAndNotify(): Promise<void> {
  const accountSid = process.env["TWILIO_ACCOUNT_SID"];
  const authToken = process.env["TWILIO_AUTH_TOKEN"];
  const fromNumber = process.env["TWILIO_WHATSAPP_FROM"];
  const adminPhone = process.env["ADMIN_WHATSAPP_NUMBER"] ?? "01105448596";

  if (!accountSid || !authToken || !fromNumber) {
    return;
  }

  const client = twilio(accountSid, authToken);
  const today = getTodayName();
  const now = new Date();
  const minutesNow = now.getHours() * 60 + now.getMinutes();
  const targetMinutes = minutesNow + 5;

  const rows = await db
    .select({
      id: schedulesTable.id,
      startTime: schedulesTable.startTime,
      studentName: studentsTable.name,
      teacherName: teachersTable.name,
      teacherPhone: teachersTable.phone,
    })
    .from(schedulesTable)
    .leftJoin(studentsTable, eq(schedulesTable.studentId, studentsTable.id))
    .leftJoin(teachersTable, eq(schedulesTable.teacherId, teachersTable.id))
    .where(and(eq(schedulesTable.active, true), eq(schedulesTable.dayOfWeek, today)));

  for (const row of rows) {
    const [h, m] = row.startTime.split(":").map(Number);
    const sessionMinutes = h * 60 + m;
    if (sessionMinutes !== targetMinutes) continue;

    const body = `تذكير 📚 بعد 5 دقائق حلقة ${row.studentName ?? "طالب"} مع ${row.teacherName ?? "معلم"} الساعة ${row.startTime}`;

    const recipients = new Set<string>([adminPhone]);
    if (row.teacherPhone) recipients.add(row.teacherPhone);

    for (const phone of recipients) {
      try {
        await client.messages.create({
          from: fromNumber,
          to: `whatsapp:${toE164Egypt(phone)}`,
          body,
        });
        logger.info({ scheduleId: row.id, phone }, "WhatsApp reminder sent");
      } catch (err) {
        logger.error({ err, scheduleId: row.id, phone }, "Failed to send WhatsApp reminder");
      }
    }
  }
}

export function startWhatsAppReminders(): void {
  schedule.scheduleJob("* * * * *", () => {
    checkAndNotify().catch((err: unknown) => logger.error({ err }, "WhatsApp reminder check error"));
  });
  logger.info("WhatsApp reminder scheduler started");
}
