import { getAuth } from "@clerk/express";
import { db, deductionsTable, profilesTable, schedulesTable, sessionLogsTable, studentsTable, teachersTable } from "@workspace/db";
import {
  CreateScheduleBody,
  CreateSessionLogBody,
  CreateStudentBody,
  CreateTeacherBody,
  DeleteScheduleParams,
  DeleteStudentParams,
  DeleteTeacherParams,
  GetCurrentProfileResponse,
  GetDashboardResponse,
  GetFinanceReportResponse,
  ListProfilesResponse,
  ListSchedulesResponse,
  ListSchedulesResponseItem,
  ListSessionLogsResponse,
  ListSessionLogsResponseItem,
  ListStudentsResponse,
  ListStudentsResponseItem,
  ListTeachersResponse,
  ListTeachersResponseItem,
  UpdateProfileBody,
  UpdateProfileParams,
  UpdateProfileResponse,
  UpdateScheduleBody,
  UpdateScheduleParams,
  UpdateScheduleResponse,
  UpdateStudentBody,
  UpdateStudentParams,
  UpdateStudentResponse,
  UpdateTeacherBody,
  UpdateTeacherParams,
  UpdateTeacherResponse,
} from "@workspace/api-zod";
import { and, count, desc, eq, gte, lt, sql } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";

const router: IRouter = Router();

type Profile = typeof profilesTable.$inferSelect;
type Teacher = typeof teachersTable.$inferSelect;
type Student = typeof studentsTable.$inferSelect;
type Schedule = typeof schedulesTable.$inferSelect;
type SessionLog = typeof sessionLogsTable.$inferSelect;

function getClaim(claims: unknown, keys: string[]): string | null {
  if (!claims || typeof claims !== "object") return null;
  const source = claims as Record<string, unknown>;
  for (const key of keys) {
    const value = source[key];
    if (typeof value === "string" && value.trim()) return value;
  }
  return null;
}

async function ensureProfile(req: Request, res: Response): Promise<Profile | null> {
  const auth = getAuth(req);
  const userId = auth.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }

  const [existing] = await db.select().from(profilesTable).where(eq(profilesTable.id, userId));
  if (existing) return existing;

  const claims = auth.sessionClaims;
  const email = getClaim(claims, ["email", "email_address", "primary_email_address"]) ?? `${userId}@moddaker.local`;
  const name = getClaim(claims, ["name", "full_name", "given_name"]) ?? "مستخدم مُدكر";
  const [{ value: profilesCount }] = await db.select({ value: count() }).from(profilesTable);
  const [teacher] = await db.select().from(teachersTable).where(eq(teachersTable.email, email)).limit(1);

  const [created] = await db
    .insert(profilesTable)
    .values({
      id: userId,
      name,
      email,
      role: profilesCount === 0 ? "admin" : "teacher",
      teacherId: teacher?.id ?? null,
    })
    .returning();

  return created ?? null;
}

function canManage(profile: Profile): boolean {
  return profile.role === "admin" || profile.role === "supervisor";
}

function canManageTeachers(profile: Profile): boolean {
  return profile.role === "admin";
}

function profileToApi(profile: Profile) {
  return {
    id: profile.id,
    name: profile.name,
    email: profile.email,
    role: profile.role,
    teacherId: profile.teacherId,
  };
}

function teacherToApi(teacher: Teacher) {
  return {
    id: teacher.id,
    name: teacher.name,
    email: teacher.email,
    phone: teacher.phone,
    sessionRate: teacher.sessionRateCents / 100,
    active: teacher.active,
  };
}

function scheduleToApi(schedule: Schedule, studentName: string, teacherName: string | null) {
  return {
    id: schedule.id,
    studentId: schedule.studentId,
    teacherId: schedule.teacherId,
    dayOfWeek: schedule.dayOfWeek,
    startTime: schedule.startTime,
    active: schedule.active,
    studentName,
    teacherName,
  };
}

function studentToApi(student: Student, schedules: Array<ReturnType<typeof scheduleToApi>>) {
  return {
    id: student.id,
    name: student.name,
    totalSessionsBought: student.totalSessionsBought,
    sessionsRemaining: student.sessionsRemaining,
    notes: student.notes,
    active: student.active,
    schedules,
  };
}

function sessionLogToApi(log: SessionLog, studentName: string, teacherName: string | null) {
  return {
    id: log.id,
    studentId: log.studentId,
    teacherId: log.teacherId,
    scheduleId: log.scheduleId,
    status: log.status,
    rescheduledDayOfWeek: log.rescheduledDayOfWeek,
    rescheduledStartTime: log.rescheduledStartTime,
    notes: log.notes,
    createdAt: log.createdAt.toISOString(),
    studentName,
    teacherName,
  };
}

async function getSchedules() {
  const rows = await db
    .select({ schedule: schedulesTable, student: studentsTable, teacher: teachersTable })
    .from(schedulesTable)
    .leftJoin(studentsTable, eq(schedulesTable.studentId, studentsTable.id))
    .leftJoin(teachersTable, eq(schedulesTable.teacherId, teachersTable.id))
    .orderBy(schedulesTable.dayOfWeek, schedulesTable.startTime);

  return rows.map((row) =>
    scheduleToApi(row.schedule, row.student?.name ?? "طالب غير معروف", row.teacher?.name ?? null),
  );
}

async function getStudents() {
  const [students, schedules] = await Promise.all([
    db.select().from(studentsTable).where(eq(studentsTable.active, true)).orderBy(studentsTable.id),
    getSchedules(),
  ]);

  return students.map((student) =>
    studentToApi(
      student,
      schedules.filter((schedule) => schedule.studentId === student.id),
    ),
  );
}

async function getSessionLogs() {
  const rows = await db
    .select({ log: sessionLogsTable, student: studentsTable, teacher: teachersTable })
    .from(sessionLogsTable)
    .leftJoin(studentsTable, eq(sessionLogsTable.studentId, studentsTable.id))
    .leftJoin(teachersTable, eq(sessionLogsTable.teacherId, teachersTable.id))
    .orderBy(desc(sessionLogsTable.createdAt));

  return rows.map((row) =>
    sessionLogToApi(row.log, row.student?.name ?? "طالب غير معروف", row.teacher?.name ?? null),
  );
}

router.get("/academy/me", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  res.json(GetCurrentProfileResponse.parse(profileToApi(profile)));
});

router.get("/academy/profiles", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  if (!canManage(profile)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const profiles = await db.select().from(profilesTable).orderBy(profilesTable.createdAt);
  res.json(ListProfilesResponse.parse(profiles.map(profileToApi)));
});

router.patch("/academy/profiles/:id", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  if (profile.role !== "admin") {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const params = UpdateProfileParams.safeParse(req.params);
  const body = UpdateProfileBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid profile update" });
    return;
  }

  const [updated] = await db
    .update(profilesTable)
    .set(body.data)
    .where(eq(profilesTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Profile not found" });
    return;
  }

  res.json(UpdateProfileResponse.parse(profileToApi(updated)));
});

router.get("/academy/dashboard", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;

  const [students, teachers, schedules, logs] = await Promise.all([
    getStudents(),
    db.select().from(teachersTable),
    getSchedules(),
    getSessionLogs(),
  ]);

  res.json(
    GetDashboardResponse.parse({
      studentsCount: students.length,
      teachersCount: teachers.filter((teacher) => teacher.active).length,
      activeSchedulesCount: schedules.filter((schedule) => schedule.active).length,
      completedSessionsCount: logs.filter((log) => log.status === "completed").length,
      postponedSessionsCount: logs.filter((log) => log.status === "postponed").length,
      lowBalanceStudents: students.filter((student) => student.sessionsRemaining <= 2).slice(0, 5),
      upcomingSchedules: schedules.filter((schedule) => schedule.active).slice(0, 8),
    }),
  );
});

router.get("/academy/students", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  res.json(ListStudentsResponse.parse(await getStudents()));
});

router.post("/academy/students", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  if (!canManage(profile)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const body = CreateStudentBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [student] = await db
    .insert(studentsTable)
    .values({
      name: body.data.name,
      totalSessionsBought: body.data.totalSessionsBought,
      sessionsRemaining: body.data.totalSessionsBought,
      notes: body.data.notes ?? null,
    })
    .returning();

  if (!student) {
    res.status(500).json({ error: "Student was not created" });
    return;
  }

  if (body.data.schedules.length > 0) {
    await db.insert(schedulesTable).values(
      body.data.schedules.map((schedule) => ({
        studentId: student.id,
        teacherId: schedule.teacherId ?? null,
        dayOfWeek: schedule.dayOfWeek,
        startTime: schedule.startTime,
        active: true,
      })),
    );
  }

  const schedules = (await getSchedules()).filter((schedule) => schedule.studentId === student.id);
  res.status(201).json(ListStudentsResponseItem.parse(studentToApi(student, schedules)));
});

router.patch("/academy/students/:id", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  if (!canManage(profile)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const params = UpdateStudentParams.safeParse(req.params);
  const body = UpdateStudentBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid student update" });
    return;
  }

  const [updated] = await db
    .update(studentsTable)
    .set(body.data)
    .where(eq(studentsTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Student not found" });
    return;
  }

  const schedules = (await getSchedules()).filter((schedule) => schedule.studentId === updated.id);
  res.json(UpdateStudentResponse.parse(studentToApi(updated, schedules)));
});

router.delete("/academy/students/:id", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  if (!canManage(profile)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const params = DeleteStudentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  await db.update(schedulesTable).set({ active: false }).where(eq(schedulesTable.studentId, params.data.id));
  const [deleted] = await db.update(studentsTable).set({ active: false }).where(eq(studentsTable.id, params.data.id)).returning();
  if (!deleted) {
    res.status(404).json({ error: "Student not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/academy/teachers", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  const teachers = await db.select().from(teachersTable).orderBy(teachersTable.id);
  res.json(ListTeachersResponse.parse(teachers.map(teacherToApi)));
});

router.post("/academy/teachers", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  if (!canManageTeachers(profile)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const body = CreateTeacherBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [teacher] = await db
    .insert(teachersTable)
    .values({
      name: body.data.name,
      email: body.data.email,
      phone: body.data.phone ?? null,
      sessionRateCents: Math.round(body.data.sessionRate * 100),
    })
    .returning();

  if (!teacher) {
    res.status(500).json({ error: "Teacher was not created" });
    return;
  }

  res.status(201).json(ListTeachersResponseItem.parse(teacherToApi(teacher)));
});

router.patch("/academy/teachers/:id", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  if (!canManageTeachers(profile)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const params = UpdateTeacherParams.safeParse(req.params);
  const body = UpdateTeacherBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid teacher update" });
    return;
  }

  const update = {
    ...body.data,
    sessionRateCents:
      body.data.sessionRate == null ? undefined : Math.round(body.data.sessionRate * 100),
  };
  const { sessionRate: _sessionRate, ...values } = update;
  const [teacher] = await db
    .update(teachersTable)
    .set(values)
    .where(eq(teachersTable.id, params.data.id))
    .returning();

  if (!teacher) {
    res.status(404).json({ error: "Teacher not found" });
    return;
  }

  res.json(UpdateTeacherResponse.parse(teacherToApi(teacher)));
});

router.delete("/academy/teachers/:id", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  if (!canManageTeachers(profile)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const params = DeleteTeacherParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  await db.update(profilesTable).set({ teacherId: null }).where(eq(profilesTable.teacherId, params.data.id));
  const [deleted] = await db.update(teachersTable).set({ active: false }).where(eq(teachersTable.id, params.data.id)).returning();
  if (!deleted) {
    res.status(404).json({ error: "Teacher not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/academy/schedules", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  res.json(ListSchedulesResponse.parse(await getSchedules()));
});

router.post("/academy/schedules", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  if (!canManage(profile)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const body = CreateScheduleBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [schedule] = await db
    .insert(schedulesTable)
    .values({
      studentId: body.data.studentId,
      teacherId: body.data.teacherId ?? null,
      dayOfWeek: body.data.dayOfWeek,
      startTime: body.data.startTime,
    })
    .returning();

  if (!schedule) {
    res.status(500).json({ error: "Schedule was not created" });
    return;
  }

  const [apiSchedule] = (await getSchedules()).filter((item) => item.id === schedule.id);
  res.status(201).json(ListSchedulesResponseItem.parse(apiSchedule));
});

router.patch("/academy/schedules/:id", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  if (!canManage(profile)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const params = UpdateScheduleParams.safeParse(req.params);
  const body = UpdateScheduleBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid schedule update" });
    return;
  }

  const [schedule] = await db
    .update(schedulesTable)
    .set(body.data)
    .where(eq(schedulesTable.id, params.data.id))
    .returning();

  if (!schedule) {
    res.status(404).json({ error: "Schedule not found" });
    return;
  }

  const [apiSchedule] = (await getSchedules()).filter((item) => item.id === schedule.id);
  res.json(UpdateScheduleResponse.parse(apiSchedule));
});

router.delete("/academy/schedules/:id", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  if (!canManage(profile)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const params = DeleteScheduleParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db.update(schedulesTable).set({ active: false }).where(eq(schedulesTable.id, params.data.id)).returning();
  if (!deleted) {
    res.status(404).json({ error: "Schedule not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/academy/teacher-schedules", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;

  const schedules = await getSchedules();
  const teacherSchedules = profile.role === "teacher"
    ? schedules.filter((schedule) => schedule.active && schedule.teacherId === profile.teacherId)
    : schedules.filter((schedule) => schedule.active);
  res.json(ListSchedulesResponse.parse(teacherSchedules));
});

router.get("/academy/session-logs", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  const logs = await getSessionLogs();
  res.json(profile.role === "teacher" && profile.teacherId
    ? logs.filter((log) => log.teacherId === profile.teacherId)
    : logs);
});

router.post("/academy/session-logs", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;

  const body = CreateSessionLogBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  let teacherId = body.data.teacherId ?? profile.teacherId ?? null;
  let schedule: Schedule | undefined;
  if (body.data.scheduleId != null) {
    [schedule] = await db.select().from(schedulesTable).where(eq(schedulesTable.id, body.data.scheduleId));
    teacherId = teacherId ?? schedule?.teacherId ?? null;
  }

  if (profile.role === "teacher" && (!profile.teacherId || teacherId !== profile.teacherId)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const rescheduledDayOfWeek = typeof req.body?.rescheduledDayOfWeek === "string" ? req.body.rescheduledDayOfWeek : null;
  const rescheduledStartTime = typeof req.body?.rescheduledStartTime === "string" ? req.body.rescheduledStartTime : null;

  const [log] = await db
    .insert(sessionLogsTable)
    .values({
      studentId: body.data.studentId,
      teacherId,
      scheduleId: body.data.scheduleId ?? null,
      status: body.data.status,
      rescheduledDayOfWeek,
      rescheduledStartTime,
      notes: body.data.notes ?? null,
    })
    .returning();

  if (!log) {
    res.status(500).json({ error: "Session log was not created" });
    return;
  }

  if (body.data.status === "completed") {
    await db
      .update(studentsTable)
      .set({ sessionsRemaining: sql`GREATEST(${studentsTable.sessionsRemaining} - 1, 0)` })
      .where(eq(studentsTable.id, body.data.studentId));
  }

  if (body.data.status === "postponed" && schedule && rescheduledDayOfWeek && rescheduledStartTime) {
    await db
      .update(schedulesTable)
      .set({ dayOfWeek: rescheduledDayOfWeek, startTime: rescheduledStartTime, active: true })
      .where(eq(schedulesTable.id, schedule.id));
  }

  const [apiLog] = (await getSessionLogs()).filter((item) => item.id === log.id);
  res.status(201).json(ListSessionLogsResponseItem.parse(apiLog));
});

router.get("/academy/finance", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  if (profile.role !== "admin") {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const nextMonthStart = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  const teachers = await db.select().from(teachersTable).orderBy(teachersTable.id);
  const rows = await Promise.all(
    teachers.map(async (teacher) => {
      const [{ value }] = await db
        .select({ value: count() })
        .from(sessionLogsTable)
        .where(and(
          eq(sessionLogsTable.teacherId, teacher.id),
          eq(sessionLogsTable.status, "completed"),
          gte(sessionLogsTable.createdAt, monthStart),
          lt(sessionLogsTable.createdAt, nextMonthStart),
        ));
      const deductions = await db
        .select()
        .from(deductionsTable)
        .where(and(
          eq(deductionsTable.teacherId, teacher.id),
          gte(deductionsTable.createdAt, monthStart),
          lt(deductionsTable.createdAt, nextMonthStart),
        ))
        .orderBy(desc(deductionsTable.createdAt));
      const studentRows = await db
        .select({ studentName: studentsTable.name, sessions: count() })
        .from(sessionLogsTable)
        .leftJoin(studentsTable, eq(sessionLogsTable.studentId, studentsTable.id))
        .where(and(
          eq(sessionLogsTable.teacherId, teacher.id),
          eq(sessionLogsTable.status, "completed"),
          gte(sessionLogsTable.createdAt, monthStart),
          lt(sessionLogsTable.createdAt, nextMonthStart),
        ))
        .groupBy(studentsTable.name);
      const sessionRate = teacher.sessionRateCents / 100;
      const deductionTotal = deductions.reduce((sum, deduction) => sum + deduction.amountCents / 100, 0);
      return {
        teacherId: teacher.id,
        teacherName: teacher.name,
        completedSessions: value,
        sessionRate,
        grossSalary: value * sessionRate,
        deductionsTotal: deductionTotal,
        totalSalary: value * sessionRate - deductionTotal,
        deductions: deductions.map((deduction) => ({
          id: deduction.id,
          amount: deduction.amountCents / 100,
          reason: deduction.reason,
          createdAt: deduction.createdAt.toISOString(),
        })),
        studentBreakdown: studentRows.map((row) => ({
          studentName: row.studentName ?? "طالب غير معروف",
          sessions: row.sessions,
        })),
      };
    }),
  );

  res.json(rows);
});

router.post("/academy/users", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  if (profile.role !== "admin") {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const { name, email, password, role, teacherId } = req.body ?? {};
  if (!name || !email || !password || !role) {
    res.status(400).json({ error: "name, email, password, role are required" });
    return;
  }
  const allowedRoles = ["admin", "supervisor", "teacher"];
  if (!allowedRoles.includes(role)) {
    res.status(400).json({ error: "Invalid role" });
    return;
  }

  const { createClerkClient } = await import("@clerk/backend");
  const clerk = createClerkClient({ secretKey: process.env["CLERK_SECRET_KEY"] });

  let newUserId: string;
  try {
    const user = await clerk.users.createUser({
      emailAddress: [email],
      password,
      firstName: name,
    });
    newUserId = user.id;
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Failed to create Clerk user";
    res.status(500).json({ error: msg });
    return;
  }

  const [existing] = await db.select().from(profilesTable).where(eq(profilesTable.id, newUserId));
  if (!existing) {
    await db.insert(profilesTable).values({
      id: newUserId,
      name,
      email,
      role,
      teacherId: teacherId ? Number(teacherId) : null,
    });
  } else if (existing.role !== role || (teacherId && existing.teacherId !== Number(teacherId))) {
    await db.update(profilesTable).set({ role, teacherId: teacherId ? Number(teacherId) : existing.teacherId }).where(eq(profilesTable.id, newUserId));
  }

  res.status(201).json({ id: newUserId, name, email, role });
});

router.post("/academy/deductions", async (req, res): Promise<void> => {
  const profile = await ensureProfile(req, res);
  if (!profile) return;
  if (profile.role !== "admin") {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const teacherId = Number(req.body?.teacherId);
  const amount = Number(req.body?.amount);
  const reason = typeof req.body?.reason === "string" ? req.body.reason.trim() : "";
  if (!teacherId || !Number.isFinite(amount) || amount <= 0 || !reason) {
    res.status(400).json({ error: "Invalid deduction" });
    return;
  }

  const [deduction] = await db.insert(deductionsTable).values({
    teacherId,
    amountCents: Math.round(amount * 100),
    reason,
  }).returning();

  res.status(201).json({
    id: deduction.id,
    teacherId: deduction.teacherId,
    amount: deduction.amountCents / 100,
    reason: deduction.reason,
    createdAt: deduction.createdAt.toISOString(),
  });
});

export default router;