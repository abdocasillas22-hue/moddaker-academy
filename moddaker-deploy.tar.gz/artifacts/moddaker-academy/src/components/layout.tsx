import { useEffect, useState } from "react";
import { Link, Redirect, useLocation } from "wouter";
import { 
  useGetCurrentProfile, 
  getGetCurrentProfileQueryKey,
  useListSchedules,
  getListSchedulesQueryKey,
  useListTeacherSchedules,
  getListTeacherSchedulesQueryKey
} from "@workspace/api-client-react";
import { Loader2, LayoutDashboard, Users, UserSquare2, CalendarDays, BookOpen, ScrollText, DollarSign, LogOut, Menu, X, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth, useClerk } from "@clerk/react";
import { useToast } from "@/hooks/use-toast";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  const { toast } = useToast();
  const { isLoaded, isSignedIn } = useAuth();
  const { data: profile, isLoading } = useGetCurrentProfile({
    query: {
      queryKey: getGetCurrentProfileQueryKey(),
      enabled: isSignedIn === true,
    }
  });

  const { signOut } = useClerk();
  const { data: allSchedules } = useListSchedules({
    query: {
      queryKey: getListSchedulesQueryKey(),
      enabled: profile?.role === "admin" || profile?.role === "supervisor",
      refetchInterval: 60000,
    }
  });
  const { data: teacherSchedules } = useListTeacherSchedules({
    query: {
      queryKey: getListTeacherSchedulesQueryKey(),
      enabled: profile?.role === "teacher",
      refetchInterval: 60000,
    }
  });

  useEffect(() => {
    const schedules = profile?.role === "teacher" ? teacherSchedules : allSchedules;
    if (!profile || !schedules?.length) return;

    const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const today = dayNames[new Date().getDay()];
    const notifiedKey = "moddaker-notified-lessons";
    const notified = new Set(JSON.parse(localStorage.getItem(notifiedKey) || "[]") as string[]);

    const checkNotifications = () => {
      const now = new Date();
      const minutesNow = now.getHours() * 60 + now.getMinutes();
      schedules
        .filter((schedule) => schedule.active && schedule.dayOfWeek === today)
        .forEach((schedule) => {
          const [hour, minute] = schedule.startTime.split(":").map(Number);
          const minutesLesson = hour * 60 + minute;
          const diff = minutesLesson - minutesNow;
          const key = `${schedule.id}-${now.toDateString()}`;
          if (diff >= 0 && diff <= 5 && !notified.has(key)) {
            const message = `عندك حلقة بعد ${Math.max(diff, 1)} دقائق: ${schedule.studentName}`;
            toast({ title: "تنبيه حلقة قريبة", description: message });
            if ("Notification" in window) {
              if (Notification.permission === "granted") {
                new Notification("أكاديمية مدكر", { body: message });
              } else if (Notification.permission !== "denied") {
                Notification.requestPermission();
              }
            }
            notified.add(key);
            localStorage.setItem(notifiedKey, JSON.stringify([...notified].slice(-100)));
          }
        });
    };

    checkNotifications();
    const interval = window.setInterval(checkNotifications, 60000);
    return () => window.clearInterval(interval);
  }, [allSchedules, profile, teacherSchedules, toast]);

  if (!isLoaded || (isSignedIn && isLoading)) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isSignedIn) {
    return <Redirect to="/" />;
  }

  if (!profile) {
    return <Redirect to="/" />;
  }

  const navItems = [
    { href: "/dashboard", label: "لوحة التحكم", icon: LayoutDashboard, roles: ["admin", "supervisor", "teacher"] },
    { href: "/students", label: "الطلاب", icon: Users, roles: ["admin", "supervisor"] },
    { href: "/teachers", label: "المعلمين", icon: UserSquare2, roles: ["admin", "supervisor"] },
    { href: "/schedules", label: "الجداول", icon: CalendarDays, roles: ["admin", "supervisor"] },
    { href: "/teacher", label: "حصصي", icon: BookOpen, roles: ["teacher", "admin"] },
    { href: "/logs", label: "سجل الحصص", icon: ScrollText, roles: ["admin", "supervisor"] },
    { href: "/finance", label: "المالية", icon: DollarSign, roles: ["admin"] },
    { href: "/users", label: "المستخدمين", icon: ShieldCheck, roles: ["admin"] },
  ];

  const visibleNavItems = navItems.filter((item) => 
    item.roles.includes(profile.role)
  );

  const sidebarContent = (
    <>
      <div className="flex h-16 items-center justify-between border-b border-sidebar-border px-4">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg overflow-hidden border border-sidebar-primary/30">
            <img src="/logo.jpg" alt="Logo" className="h-full w-full object-cover" />
          </div>
          <span className="text-base font-bold text-sidebar-foreground">مدكر</span>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={() => setMobileMenuOpen(false)}
          aria-label="إغلاق القائمة"
        >
          <X className="h-5 w-5" />
        </Button>
      </div>
      <div className="flex min-h-0 flex-1 flex-col p-4">
        <div className="mb-4 rounded-2xl border border-sidebar-border bg-background/60 p-4">
          <p className="text-sm font-bold text-sidebar-foreground">{profile.name}</p>
          <p className="mt-1 text-xs text-sidebar-foreground/70">{
            profile.role === 'admin' ? 'مدير' :
            profile.role === 'supervisor' ? 'مشرف' : 'معلم'
          }</p>
        </div>
        <nav className="flex flex-col gap-1">
          {visibleNavItems.map((item) => {
            const active = location === item.href;
            return (
              <Link key={item.href} href={item.href}>
                <Button
                  variant={active ? "secondary" : "ghost"}
                  className="h-12 w-full justify-start gap-3 rounded-xl text-base hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <item.icon className="h-5 w-5" />
                  {item.label}
                </Button>
              </Link>
            );
          })}
        </nav>
        <Button
          variant="ghost"
          className="mt-auto h-12 w-full justify-start gap-3 rounded-xl text-destructive hover:bg-destructive/10 hover:text-destructive"
          onClick={() => signOut({ redirectUrl: '/' })}
        >
          <LogOut className="h-5 w-5" />
          تسجيل الخروج
        </Button>
      </div>
    </>
  );

  return (
    <div className="flex min-h-screen w-full overflow-x-hidden bg-background" dir="rtl">
      <aside className="sticky top-0 hidden h-screen w-72 flex-shrink-0 flex-col border-l bg-sidebar md:flex">
        {sidebarContent}
      </aside>

      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <button
            className="absolute inset-0 bg-black/35"
            onClick={() => setMobileMenuOpen(false)}
            aria-label="إغلاق القائمة"
          />
          <aside className="absolute right-0 top-0 flex h-full w-[82vw] max-w-80 flex-col border-l bg-sidebar shadow-2xl">
            {sidebarContent}
          </aside>
        </div>
      )}

      <main className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b bg-card/95 px-4 shadow-sm backdrop-blur md:px-8">
          <div>
            <p className="text-xs text-muted-foreground">أهلاً بك</p>
            <p className="max-w-[180px] truncate text-sm font-bold sm:max-w-none">{profile.name}</p>
          </div>
          <Button
            variant="outline"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(true)}
            aria-label="فتح القائمة"
          >
            <Menu className="h-5 w-5" />
          </Button>
        </header>
        <div className="min-w-0 flex-1 overflow-auto p-4 sm:p-6 lg:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
