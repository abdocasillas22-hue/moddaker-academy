import { useGetDashboard, getGetDashboardQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, Users, UserSquare2, Calendar, CheckCircle2, AlertCircle } from "lucide-react";
import { formatTime } from "@/lib/utils";

export default function Dashboard() {
  const { data: dashboard, isLoading } = useGetDashboard({
    query: { queryKey: getGetDashboardQueryKey() }
  });

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!dashboard) {
    return null;
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">لوحة التحكم</h2>
        <p className="text-muted-foreground mt-2">نظرة عامة على نشاط الأكاديمية</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الطلاب</CardTitle>
            <Users className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboard.studentsCount}</div>
          </CardContent>
        </Card>
        
        <Card className="bg-secondary/30 border-secondary/50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">المعلمين النشطين</CardTitle>
            <UserSquare2 className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboard.teachersCount}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">الحصص المجدولة</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboard.activeSchedulesCount}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">الحصص المكتملة</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboard.completedSessionsCount}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-destructive" />
              أرصدة منخفضة
            </CardTitle>
            <CardDescription>طلاب يحتاجون لتجديد الباقة (أقل من 3 حصص)</CardDescription>
          </CardHeader>
          <CardContent>
            {dashboard.lowBalanceStudents.length === 0 ? (
              <p className="text-sm text-muted-foreground">لا يوجد طلاب بأرصدة منخفضة حالياً.</p>
            ) : (
              <div className="space-y-4">
                {dashboard.lowBalanceStudents.map(student => (
                  <div key={student.id} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
                    <div>
                      <p className="font-medium">{student.name}</p>
                      <p className="text-sm text-muted-foreground">الإجمالي: {student.totalSessionsBought}</p>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                        student.sessionsRemaining === 0 ? 'bg-destructive/10 text-destructive' : 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-500'
                      }`}>
                        {student.sessionsRemaining} حصة متبقية
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              حصص اليوم
            </CardTitle>
            <CardDescription>الحصص المجدولة لليوم</CardDescription>
          </CardHeader>
          <CardContent>
            {dashboard.upcomingSchedules.length === 0 ? (
              <p className="text-sm text-muted-foreground">لا يوجد حصص مجدولة اليوم.</p>
            ) : (
              <div className="space-y-4">
                {dashboard.upcomingSchedules.map(schedule => (
                  <div key={schedule.id} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
                    <div>
                      <p className="font-medium text-primary">{formatTime(schedule.startTime)}</p>
                      <p className="text-sm">الطالب: <span className="font-medium">{schedule.studentName}</span></p>
                    </div>
                    <div className="text-left">
                      <p className="text-sm text-muted-foreground">المعلم</p>
                      <p className="text-sm font-medium">{schedule.teacherName || "غير محدد"}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
