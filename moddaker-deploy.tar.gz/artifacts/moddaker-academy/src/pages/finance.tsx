import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { 
  useGetFinanceReport, 
  getGetFinanceReportQueryKey 
} from "@workspace/api-client-react";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Calculator, MinusCircle, FileText } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatCurrency, formatDate } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function Finance() {
  const { toast } = useToast();
  const { data: rows, isLoading } = useGetFinanceReport({
    query: { queryKey: getGetFinanceReportQueryKey() }
  });
  const reportRows = (rows || []) as any[];
  const [deductionDialog, setDeductionDialog] = useState<{ teacherId: number; teacherName: string } | null>(null);
  const [deductionData, setDeductionData] = useState({ amount: 0, reason: "" });

  const addDeduction = useMutation({
    mutationFn: async () => {
      if (!deductionDialog) return;
      const response = await fetch(`${import.meta.env.BASE_URL}api/academy/deductions`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          teacherId: deductionDialog.teacherId,
          amount: deductionData.amount,
          reason: deductionData.reason,
        }),
      });
      if (!response.ok) throw new Error("تعذر تسجيل الخصم");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: getGetFinanceReportQueryKey() });
      setDeductionDialog(null);
      setDeductionData({ amount: 0, reason: "" });
      toast({ title: "تم تسجيل الخصم", description: "الخصم اتسجل في تاريخ المعلم." });
    },
  });

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const grandTotal = reportRows.reduce((acc, row) => acc + row.totalSalary, 0);
  const grossTotal = reportRows.reduce((acc, row) => acc + (row.grossSalary ?? row.totalSalary), 0);
  const deductionsTotal = reportRows.reduce((acc, row) => acc + (row.deductionsTotal ?? 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">التقرير المالي</h2>
          <p className="text-muted-foreground">حساب شهري من أول يوم في الشهر لآخره مع الخصومات وتفصيل الطلاب.</p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">صافي الرواتب</CardTitle>
            <Calculator className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{formatCurrency(grandTotal)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">قبل الخصم</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(grossTotal)}</div>
          </CardContent>
        </Card>
        <Card className="border-destructive/20 bg-destructive/5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الخصومات</CardTitle>
            <MinusCircle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{formatCurrency(deductionsTotal)}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-right">المعلم</TableHead>
              <TableHead className="text-right">تفصيل الطلاب</TableHead>
              <TableHead className="text-right">الحصص</TableHead>
              <TableHead className="text-right">قبل الخصم</TableHead>
              <TableHead className="text-right">الخصومات</TableHead>
              <TableHead className="text-right">الصافي</TableHead>
              <TableHead className="text-right">إجراء</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {reportRows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  لا يوجد بيانات مالية للعرض
                </TableCell>
              </TableRow>
            ) : (
              reportRows.map((row) => (
                <TableRow key={row.teacherId} className="align-top">
                  <TableCell className="font-medium">{row.teacherName}</TableCell>
                  <TableCell>
                    <div className="space-y-1 text-sm">
                      {row.studentBreakdown?.length ? row.studentBreakdown.map((student: any) => (
                        <div key={student.studentName} className="rounded-lg bg-muted/50 px-2 py-1">
                          {student.studentName}: {student.sessions} حصة
                        </div>
                      )) : <span className="text-muted-foreground">لا يوجد حصص هذا الشهر</span>}
                    </div>
                  </TableCell>
                  <TableCell>{row.completedSessions}</TableCell>
                  <TableCell>{formatCurrency(row.grossSalary ?? row.totalSalary)}</TableCell>
                  <TableCell>
                    <div className="space-y-2">
                      <p className="font-semibold text-destructive">{formatCurrency(row.deductionsTotal ?? 0)}</p>
                      {row.deductions?.map((deduction: any) => (
                        <div key={deduction.id} className="rounded-lg border p-2 text-xs text-muted-foreground">
                          <p>{formatCurrency(deduction.amount)} - {deduction.reason}</p>
                          <p>{formatDate(deduction.createdAt)}</p>
                        </div>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell className="font-bold text-primary">{formatCurrency(row.totalSalary)}</TableCell>
                  <TableCell>
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-2"
                      onClick={() => setDeductionDialog({ teacherId: row.teacherId, teacherName: row.teacherName })}
                    >
                      <MinusCircle className="h-4 w-4" />
                      خصم
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>

      <Dialog open={!!deductionDialog} onOpenChange={(open) => !open && setDeductionDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تسجيل خصم</DialogTitle>
            <DialogDescription>للمعلم: {deductionDialog?.teacherName}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="deduction-amount">قيمة الخصم</Label>
              <Input
                id="deduction-amount"
                type="number"
                value={deductionData.amount}
                onChange={e => setDeductionData({ ...deductionData, amount: Number(e.target.value) })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="deduction-reason">السبب</Label>
              <Input
                id="deduction-reason"
                value={deductionData.reason}
                onChange={e => setDeductionData({ ...deductionData, reason: e.target.value })}
                placeholder="مثال: غياب بدون اعتذار"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              onClick={() => addDeduction.mutate()}
              disabled={addDeduction.isPending || deductionData.amount <= 0 || !deductionData.reason}
            >
              {addDeduction.isPending && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
              حفظ الخصم
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
