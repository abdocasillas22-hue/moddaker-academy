import { Show } from "@clerk/react";
import { Link, Redirect } from "wouter";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/dashboard" />
      </Show>
      <Show when="signed-out">
        <div className="min-h-screen bg-background flex flex-col items-center justify-center relative overflow-hidden" dir="rtl">
          <div className="absolute top-0 right-0 w-full h-full overflow-hidden pointer-events-none">
            <div className="absolute -top-[20%] -right-[10%] w-[50%] h-[50%] rounded-full bg-primary/5 blur-[120px]" />
            <div className="absolute top-[60%] -left-[10%] w-[40%] h-[40%] rounded-full bg-accent/10 blur-[100px]" />
          </div>

          <div className="z-10 text-center max-w-2xl px-6">
            <div className="mb-10">
              <img
                src="/logo.jpg"
                alt="Moddaker Academy"
                className="h-24 w-auto object-contain mx-auto drop-shadow-md"
              />
            </div>
            <p className="text-xl md:text-xl text-muted-foreground mb-10 leading-relaxed max-w-xl mx-auto">
              نظام إدارة متكامل لحلقات القرآن الكريم. راقب الطلاب، نظم الجداول، وتابع إنجازات المعلمين بكل سهولة ويسر.
            </p>

            <Link href="/sign-in" className="inline-block">
              <Button size="lg" className="text-lg h-14 px-10 rounded-xl shadow-lg shadow-primary/25 hover:shadow-primary/40 transition-all duration-300">
                تسجيل الدخول
              </Button>
            </Link>
          </div>
        </div>
      </Show>
    </>
  );
}
