import { 
  useListSessionLogs, 
  getListSessionLogsQueryKey 
} from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatDate } from "@/lib/utils";

export default function Logs() {
  const { data: logs, isLoading } = useListSessionLogs({
    query: { queryKey: getListSessionLogsQueryKey() }
  });

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">سجل الحصص</h2>
        <p className="text-muted-foreground">تتبع جميع الأنشطة والحصص المكتملة والمؤجلة.</p>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-right">التاريخ</TableHead>
              <TableHead className="text-right">الطالب</TableHead>
              <TableHead className="text-right">المعلم</TableHead>
              <TableHead className="text-right">الحالة</TableHead>
              <TableHead className="text-right">المعاد الجديد</TableHead>
              <TableHead className="text-right">الملاحظات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {logs?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                  لا يوجد سجلات حتى الآن
                </TableCell>
              </TableRow>
            ) : (
              logs?.map((log) => (
                <TableRow key={log.id}>
                  <TableCell className="whitespace-nowrap">
                    {formatDate(log.createdAt)}
                  </TableCell>
                  <TableCell className="font-medium">{log.studentName}</TableCell>
                  <TableCell>{log.teacherName || "-"}</TableCell>
                  <TableCell>
                    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                      log.status === 'completed' 
                        ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-500' 
                        : 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-500'
                    }`}>
                      {log.status === 'completed' ? "مكتملة" : "مؤجلة"}
                    </span>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {(log as any).rescheduledDayOfWeek && (log as any).rescheduledStartTime
                      ? `${(log as any).rescheduledDayOfWeek} - ${(log as any).rescheduledStartTime}`
                      : "-"}
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm max-w-[200px] truncate" title={log.notes || ""}>
                    {log.notes || "-"}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
