import { useState } from "react";
import { 
  useListSchedules, 
  getListSchedulesQueryKey,
  useCreateSchedule,
  useUpdateSchedule,
  useDeleteSchedule,
  useListStudents,
  getListStudentsQueryKey,
  useListTeachers,
  getListTeachersQueryKey,
  DayOfWeek
} from "@workspace/api-client-react";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Plus, Edit2, Trash2, MoreHorizontal } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { formatTime } from "@/lib/utils";

const daysArabic: Record<string, string> = {
  "Saturday": "السبت",
  "Sunday": "الأحد",
  "Monday": "الاثنين",
  "Tuesday": "الثلاثاء",
  "Wednesday": "الأربعاء",
  "Thursday": "الخميس",
  "Friday": "الجمعة",
};

export default function Schedules() {
  const { toast } = useToast();
  const { data: schedules, isLoading } = useListSchedules({
    query: { queryKey: getListSchedulesQueryKey() }
  });
  
  const { data: students } = useListStudents({
    query: { queryKey: getListStudentsQueryKey() }
  });
  
  const { data: teachers } = useListTeachers({
    query: { queryKey: getListTeachersQueryKey() }
  });

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [createData, setCreateData] = useState<{
    studentId: string;
    teacherId: string;
    dayOfWeek: DayOfWeek;
    startTime: string;
  }>({
    studentId: "",
    teacherId: "",
    dayOfWeek: "Saturday" as DayOfWeek,
    startTime: "16:00"
  });

  const createSchedule = useCreateSchedule({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListSchedulesQueryKey() });
        setIsCreateOpen(false);
        setCreateData({ studentId: "", teacherId: "", dayOfWeek: "Saturday" as DayOfWeek, startTime: "16:00" });
        toast({ title: "تم الإضافة بنجاح", description: "تم إضافة الموعد بنجاح" });
      }
    }
  });

  const [editScheduleId, setEditScheduleId] = useState<number | null>(null);
  const [editData, setEditData] = useState<{
    teacherId: string;
    dayOfWeek: DayOfWeek;
    startTime: string;
    active: boolean;
  }>({
    teacherId: "",
    dayOfWeek: "Saturday" as DayOfWeek,
    startTime: "16:00",
    active: true
  });

  const updateSchedule = useUpdateSchedule({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListSchedulesQueryKey() });
        setEditScheduleId(null);
        toast({ title: "تم التحديث بنجاح", description: "تم تحديث الموعد بنجاح" });
      }
    }
  });

  const deleteSchedule = useDeleteSchedule({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListSchedulesQueryKey() });
        toast({ title: "تم الحذف بنجاح", description: "تم حذف الموعد بنجاح" });
      }
    }
  });

  const openEdit = (schedule: any) => {
    setEditScheduleId(schedule.id);
    setEditData({
      teacherId: schedule.teacherId ? schedule.teacherId.toString() : "",
      dayOfWeek: schedule.dayOfWeek,
      startTime: schedule.startTime.slice(0, 5), // 'HH:mm'
      active: schedule.active
    });
  };

  const handleCreate = () => {
    createSchedule.mutate({
      data: {
        studentId: Number(createData.studentId),
        teacherId: createData.teacherId && createData.teacherId !== "none" ? Number(createData.teacherId) : undefined,
        dayOfWeek: createData.dayOfWeek,
        startTime: createData.startTime
      }
    });
  };

  const handleEdit = () => {
    if (editScheduleId) {
      updateSchedule.mutate({
        id: editScheduleId,
        data: {
          teacherId: editData.teacherId && editData.teacherId !== "none" ? Number(editData.teacherId) : null,
          dayOfWeek: editData.dayOfWeek,
          startTime: editData.startTime,
          active: editData.active
        }
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">الجداول</h2>
          <p className="text-muted-foreground">إدارة مواعيد الحلقات الأسبوعية.</p>
        </div>
        
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              إضافة موعد
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>إضافة موعد جديد</DialogTitle>
              <DialogDescription>أدخل تفاصيل الموعد الأسبوعي.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label>الطالب</Label>
                <Select value={createData.studentId} onValueChange={(val) => setCreateData({ ...createData, studentId: val })}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر الطالب" />
                  </SelectTrigger>
                  <SelectContent>
                    {students?.map(s => <SelectItem key={s.id} value={s.id.toString()}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label>المعلم</Label>
                <Select value={createData.teacherId} onValueChange={(val) => setCreateData({ ...createData, teacherId: val })}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر المعلم (اختياري)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">بدون معلم</SelectItem>
                    {teachers?.filter(t => t.active).map(t => <SelectItem key={t.id} value={t.id.toString()}>{t.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label>اليوم</Label>
                <Select value={createData.dayOfWeek} onValueChange={(val: DayOfWeek) => setCreateData({ ...createData, dayOfWeek: val })}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر اليوم" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(daysArabic).map(([key, label]) => (
                      <SelectItem key={key} value={key}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="time">الوقت</Label>
                <Input 
                  id="time" 
                  type="time"
                  value={createData.startTime}
                  onChange={e => setCreateData({ ...createData, startTime: e.target.value })}
                />
              </div>
            </div>
            <DialogFooter>
              <Button 
                onClick={handleCreate} 
                disabled={createSchedule.isPending || !createData.studentId}
              >
                {createSchedule.isPending && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
                إضافة
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-right">اليوم والوقت</TableHead>
              <TableHead className="text-right">الطالب</TableHead>
              <TableHead className="text-right">المعلم</TableHead>
              <TableHead className="text-right">الحالة</TableHead>
              <TableHead className="text-right w-[100px]">إجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {schedules?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                  لا يوجد مواعيد مسجلة
                </TableCell>
              </TableRow>
            ) : (
              schedules?.map((schedule) => (
                <TableRow key={schedule.id}>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-medium">{daysArabic[schedule.dayOfWeek]}</span>
                      <span className="text-sm text-muted-foreground">{formatTime(schedule.startTime)}</span>
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">{schedule.studentName}</TableCell>
                  <TableCell>{schedule.teacherName || <span className="text-muted-foreground">غير محدد</span>}</TableCell>
                  <TableCell>
                    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                      schedule.active ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-500' : 'bg-muted text-muted-foreground'
                    }`}>
                      {schedule.active ? "نشط" : "متوقف"}
                    </span>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>إجراءات</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => openEdit(schedule)} className="gap-2">
                          <Edit2 className="h-4 w-4" /> تعديل
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                          className="text-destructive focus:text-destructive gap-2"
                          onClick={() => {
                            if(confirm('هل أنت متأكد من حذف هذا الموعد؟')) {
                              deleteSchedule.mutate({ id: schedule.id });
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" /> حذف
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={!!editScheduleId} onOpenChange={(open) => !open && setEditScheduleId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تعديل الموعد</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label>المعلم</Label>
              <Select value={editData.teacherId} onValueChange={(val) => setEditData({ ...editData, teacherId: val })}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر المعلم (اختياري)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون معلم</SelectItem>
                  {teachers?.filter(t => t.active).map(t => <SelectItem key={t.id} value={t.id.toString()}>{t.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>اليوم</Label>
              <Select value={editData.dayOfWeek} onValueChange={(val: DayOfWeek) => setEditData({ ...editData, dayOfWeek: val })}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر اليوم" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(daysArabic).map(([key, label]) => (
                    <SelectItem key={key} value={key}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-time">الوقت</Label>
              <Input 
                id="edit-time" 
                type="time"
                value={editData.startTime}
                onChange={e => setEditData({ ...editData, startTime: e.target.value })}
              />
            </div>
            <div className="flex items-center gap-2 mt-2">
              <input 
                type="checkbox" 
                id="edit-active" 
                checked={editData.active}
                onChange={e => setEditData({ ...editData, active: e.target.checked })}
                className="rounded border-input text-primary focus:ring-primary h-4 w-4"
              />
              <Label htmlFor="edit-active" className="cursor-pointer">موعد نشط</Label>
            </div>
          </div>
          <DialogFooter>
            <Button 
              onClick={handleEdit} 
              disabled={updateSchedule.isPending}
            >
              {updateSchedule.isPending && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
              تحديث
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
