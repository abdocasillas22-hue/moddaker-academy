import { SignIn } from "@clerk/react";

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

export default function SignInPage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4 gap-6" dir="rtl">
      <img
        src={`${basePath}/logo.jpg`}
        alt="Moddaker Academy"
        className="h-16 w-auto object-contain drop-shadow-sm"
      />
      <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
    </div>
  );
}
