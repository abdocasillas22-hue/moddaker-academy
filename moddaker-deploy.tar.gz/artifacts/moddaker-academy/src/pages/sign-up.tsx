import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function SignUpPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4" dir="rtl">
      <div className="text-center max-w-sm space-y-6">
        <div className="text-6xl">🔒</div>
        <h1 className="text-2xl font-bold text-foreground">التسجيل مقيّد</h1>
        <p className="text-muted-foreground leading-relaxed">
          التسجيل في النظام متاح فقط عن طريق المدير.
          تواصل مع مدير الأكاديمية لإنشاء حسابك.
        </p>
        <Link href="/sign-in">
          <Button className="w-full">العودة لتسجيل الدخول</Button>
        </Link>
      </div>
    </div>
  );
}
