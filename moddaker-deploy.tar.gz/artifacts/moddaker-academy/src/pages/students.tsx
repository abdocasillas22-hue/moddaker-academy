import { useState } from "react";
import { 
  useListStudents, 
  getListStudentsQueryKey,
  useCreateStudent,
  useUpdateStudent,
  useDeleteStudent,
  useListTeachers,
  getListTeachersQueryKey,
  DayOfWeek
} from "@workspace/api-client-react";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, Plus, Edit2, Trash2, CalendarDays, MoreHorizontal } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { formatTime } from "@/lib/utils";

const daysArabic: Record<string, string> = {
  "Saturday": "السبت",
  "Sunday": "الأحد",
  "Monday": "الاثنين",
  "Tuesday": "الثلاثاء",
  "Wednesday": "الأربعاء",
  "Thursday": "الخميس",
  "Friday": "الجمعة",
};

export default function Students() {
  const { toast } = useToast();
  const { data: students, isLoading } = useListStudents({
    query: { queryKey: getListStudentsQueryKey() }
  });

  const { data: teachers } = useListTeachers({
    query: { queryKey: getListTeachersQueryKey() }
  });

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [createData, setCreateData] = useState({ name: "", totalSessionsBought: 0, notes: "" });
  const [createSchedules, setCreateSchedules] = useState<Array<{ teacherId: string; dayOfWeek: DayOfWeek; startTime: string }>>([
    { teacherId: "", dayOfWeek: "Saturday" as DayOfWeek, startTime: "16:00" },
  ]);
  const createStudent = useCreateStudent({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListStudentsQueryKey() });
        setIsCreateOpen(false);
        setCreateData({ name: "", totalSessionsBought: 0, notes: "" });
        setCreateSchedules([{ teacherId: "", dayOfWeek: "Saturday" as DayOfWeek, startTime: "16:00" }]);
        toast({ title: "تم الإضافة بنجاح", description: "تم إضافة الطالب بنجاح" });
      }
    }
  });

  const [editStudentId, setEditStudentId] = useState<number | null>(null);
  const [editData, setEditData] = useState({ name: "", totalSessionsBought: 0, sessionsRemaining: 0, notes: "" });
  const updateStudent = useUpdateStudent({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListStudentsQueryKey() });
        setEditStudentId(null);
        toast({ title: "تم التحديث بنجاح", description: "تم تحديث بيانات الطالب بنجاح" });
      }
    }
  });

  const deleteStudent = useDeleteStudent({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListStudentsQueryKey() });
        toast({ title: "تم الحذف بنجاح", description: "تم حذف الطالب بنجاح" });
      }
    }
  });

  const openEdit = (student: any) => {
    setEditStudentId(student.id);
    setEditData({
      name: student.name,
      totalSessionsBought: student.totalSessionsBought,
      sessionsRemaining: student.sessionsRemaining,
      notes: student.notes || ""
    });
  };

  const handleCreate = () => {
    createStudent.mutate({
      data: {
        name: createData.name,
        totalSessionsBought: createData.totalSessionsBought,
        notes: createData.notes,
        schedules: createSchedules.map(schedule => ({
          teacherId: schedule.teacherId && schedule.teacherId !== "none" ? Number(schedule.teacherId) : undefined,
          dayOfWeek: schedule.dayOfWeek,
          startTime: schedule.startTime
        }))
      }
    });
  };

  const handleEdit = () => {
    if (editStudentId) {
      updateStudent.mutate({
        id: editStudentId,
        data: {
          name: editData.name,
          totalSessionsBought: editData.totalSessionsBought,
          sessionsRemaining: editData.sessionsRemaining,
          notes: editData.notes
        }
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">الطلاب</h2>
          <p className="text-muted-foreground">إدارة الطلاب، باقات الحصص، وأرصدة الدروس.</p>
        </div>
        
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              إضافة طالب
            </Button>
          </DialogTrigger>
            <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
            <DialogHeader>
              <DialogTitle>إضافة طالب جديد</DialogTitle>
              <DialogDescription>أدخل بيانات الطالب وحصة الباقة المشتراة.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">اسم الطالب</Label>
                <Input 
                  id="name" 
                  value={createData.name}
                  onChange={e => setCreateData({ ...createData, name: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="sessions">إجمالي الحصص (الباقة)</Label>
                <Input 
                  id="sessions" 
                  type="number"
                  value={createData.totalSessionsBought}
                  onChange={e => setCreateData({ ...createData, totalSessionsBought: Number(e.target.value) })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="notes">ملاحظات (اختياري)</Label>
                <Input 
                  id="notes" 
                  value={createData.notes}
                  onChange={e => setCreateData({ ...createData, notes: e.target.value })}
                />
              </div>
              <div className="grid gap-3 rounded-xl border bg-muted/30 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <Label>مواعيد الطالب الأسبوعية</Label>
                    <p className="text-xs text-muted-foreground">يمكنك إضافة أكثر من يوم، وكل يوم بوقت ومعلم مختلف.</p>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setCreateSchedules([...createSchedules, { teacherId: "", dayOfWeek: "Saturday" as DayOfWeek, startTime: "16:00" }])}
                  >
                    يوم جديد
                  </Button>
                </div>
                {createSchedules.map((schedule, index) => (
                  <div key={index} className="grid gap-3 rounded-lg bg-background p-3 sm:grid-cols-3">
                    <div className="grid gap-2">
                      <Label>اليوم</Label>
                      <Select
                        value={schedule.dayOfWeek}
                        onValueChange={(val: DayOfWeek) => {
                          const next = [...createSchedules];
                          next[index] = { ...next[index], dayOfWeek: val };
                          setCreateSchedules(next);
                        }}
                      >
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {Object.entries(daysArabic).map(([key, label]) => (
                            <SelectItem key={key} value={key}>{label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label>الوقت</Label>
                      <Input
                        type="time"
                        value={schedule.startTime}
                        onChange={e => {
                          const next = [...createSchedules];
                          next[index] = { ...next[index], startTime: e.target.value };
                          setCreateSchedules(next);
                        }}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label>المعلم</Label>
                      <Select
                        value={schedule.teacherId}
                        onValueChange={(val) => {
                          const next = [...createSchedules];
                          next[index] = { ...next[index], teacherId: val };
                          setCreateSchedules(next);
                        }}
                      >
                        <SelectTrigger><SelectValue placeholder="اختياري" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">بدون معلم</SelectItem>
                          {teachers?.filter(t => t.active).map(t => <SelectItem key={t.id} value={t.id.toString()}>{t.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      {createSchedules.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="text-destructive"
                          onClick={() => setCreateSchedules(createSchedules.filter((_, scheduleIndex) => scheduleIndex !== index))}
                        >
                          حذف اليوم
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <DialogFooter>
              <Button 
                onClick={handleCreate} 
                disabled={createStudent.isPending || !createData.name}
              >
                {createStudent.isPending && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
                إضافة
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-right">الطالب</TableHead>
              <TableHead className="text-right">الباقة الكلية</TableHead>
              <TableHead className="text-right">الرصيد المتبقي</TableHead>
              <TableHead className="text-right">المواعيد</TableHead>
              <TableHead className="text-right">ملاحظات</TableHead>
              <TableHead className="text-right w-[100px]">إجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {students?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                  لا يوجد طلاب مسجلين
                </TableCell>
              </TableRow>
            ) : (
              students?.map((student) => (
                <TableRow key={student.id}>
                  <TableCell className="font-medium">{student.name}</TableCell>
                  <TableCell>{student.totalSessionsBought}</TableCell>
                  <TableCell>
                    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                      student.sessionsRemaining === 0 ? 'bg-destructive/10 text-destructive' : 
                      student.sessionsRemaining <= 3 ? 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-500' :
                      'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-500'
                    }`}>
                      {student.sessionsRemaining}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-2">
                      {student.schedules.length ? student.schedules.map(schedule => (
                        <span key={schedule.id} className="rounded-full bg-secondary px-2.5 py-1 text-xs text-secondary-foreground">
                          {daysArabic[schedule.dayOfWeek]} {formatTime(schedule.startTime)}
                          {schedule.teacherName ? ` - ${schedule.teacherName}` : ""}
                        </span>
                      )) : <span className="text-muted-foreground">بدون مواعيد</span>}
                    </div>
                  </TableCell>
                  <TableCell className="text-muted-foreground">{student.notes || "-"}</TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>إجراءات</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => openEdit(student)} className="gap-2">
                          <Edit2 className="h-4 w-4" /> تعديل
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                          className="text-destructive focus:text-destructive gap-2"
                          onClick={() => {
                            if(confirm('هل أنت متأكد من حذف هذا الطالب؟')) {
                              deleteStudent.mutate({ id: student.id });
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" /> حذف
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={!!editStudentId} onOpenChange={(open) => !open && setEditStudentId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تعديل بيانات الطالب</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-name">اسم الطالب</Label>
              <Input 
                id="edit-name" 
                value={editData.name}
                onChange={e => setEditData({ ...editData, name: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-total">إجمالي الحصص (الباقة)</Label>
              <Input 
                id="edit-total" 
                type="number"
                value={editData.totalSessionsBought}
                onChange={e => setEditData({ ...editData, totalSessionsBought: Number(e.target.value) })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-rem">الرصيد المتبقي</Label>
              <Input 
                id="edit-rem" 
                type="number"
                value={editData.sessionsRemaining}
                onChange={e => setEditData({ ...editData, sessionsRemaining: Number(e.target.value) })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-notes">ملاحظات (اختياري)</Label>
              <Input 
                id="edit-notes" 
                value={editData.notes}
                onChange={e => setEditData({ ...editData, notes: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              onClick={handleEdit} 
              disabled={updateStudent.isPending || !editData.name}
            >
              {updateStudent.isPending && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
              تحديث
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
