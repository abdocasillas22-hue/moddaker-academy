import { useState } from "react";
import { 
  useListTeacherSchedules, 
  getListTeacherSchedulesQueryKey,
  useCreateSessionLog,
  SessionStatus,
  DayOfWeek
} from "@workspace/api-client-react";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle2, Clock, XCircle, CalendarClock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatTime } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const daysArabic: Record<string, string> = {
  "Saturday": "السبت",
  "Sunday": "الأحد",
  "Monday": "الاثنين",
  "Tuesday": "الثلاثاء",
  "Wednesday": "الأربعاء",
  "Thursday": "الخميس",
  "Friday": "الجمعة",
};

const dayNamesEn = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

function getTodayName(): string {
  return dayNamesEn[new Date().getDay()];
}

type LogDialogData = {
  scheduleId: number;
  studentId: number;
  status: string;
  studentName: string;
};

export default function TeacherSchedules() {
  const { toast } = useToast();
  const { data: schedules, isLoading } = useListTeacherSchedules({
    query: { queryKey: getListTeacherSchedulesQueryKey() }
  });

  const [activeLogDialog, setActiveLogDialog] = useState<LogDialogData | null>(null);
  const [notes, setNotes] = useState("");
  const [rescheduleData, setRescheduleData] = useState<{ dayOfWeek: DayOfWeek; startTime: string }>({
    dayOfWeek: "Saturday" as DayOfWeek,
    startTime: "16:00",
  });

  const createLog = useCreateSessionLog({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListTeacherSchedulesQueryKey() });
        setActiveLogDialog(null);
        setNotes("");
        toast({ title: "تم تسجيل الحصة بنجاح ✅" });
      }
    }
  });

  const openDialog = (schedule: { id: number; studentId: number; studentName: string }, status: string) => {
    setNotes("");
    setRescheduleData({ dayOfWeek: "Saturday", startTime: "16:00" });
    setActiveLogDialog({
      scheduleId: schedule.id,
      studentId: schedule.studentId,
      studentName: schedule.studentName,
      status,
    });
  };

  const handleLogSubmit = () => {
    if (!activeLogDialog) return;
    createLog.mutate({
      data: {
        studentId: activeLogDialog.studentId,
        scheduleId: activeLogDialog.scheduleId,
        status: activeLogDialog.status as SessionStatus,
        ...(activeLogDialog.status === "postponed" ? {
          rescheduledDayOfWeek: rescheduleData.dayOfWeek,
          rescheduledStartTime: rescheduleData.startTime,
        } : {}),
        notes: notes || undefined
      } as any
    });
  };

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!schedules?.length) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="rounded-full bg-primary/10 p-4 mb-4">
          <Clock className="h-8 w-8 text-primary" />
        </div>
        <h2 className="text-2xl font-bold tracking-tight">لا يوجد حصص مجدولة</h2>
        <p className="text-muted-foreground mt-2">ليس لديك أي حصص مسندة في الوقت الحالي.</p>
      </div>
    );
  }

  const today = getTodayName();
  const todaySchedules = schedules
    .filter(s => s.dayOfWeek === today)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  const otherDayOrder = ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
  const otherSchedules = schedules.filter(s => s.dayOfWeek !== today);
  const groupedOther = otherSchedules.reduce((acc, s) => {
    if (!acc[s.dayOfWeek]) acc[s.dayOfWeek] = [];
    acc[s.dayOfWeek].push(s);
    return acc;
  }, {} as Record<string, typeof schedules>);

  const SessionCard = ({ schedule, compact = false }: { schedule: (typeof schedules)[0]; compact?: boolean }) => (
    <Card className={compact ? "border-border/40" : "overflow-hidden border-primary/20 bg-primary/5 shadow-sm"}>
      <CardContent className={compact ? "p-3 space-y-3" : "p-4 space-y-4"}>
        <div className="flex justify-between items-center">
          <p className={compact ? "font-medium text-sm" : "font-bold text-base"}>{schedule.studentName}</p>
          <span className={`flex items-center gap-1 ${compact ? "text-xs text-muted-foreground" : "text-sm text-muted-foreground"}`}>
            <Clock className="w-3.5 h-3.5" />
            {formatTime(schedule.startTime)}
          </span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <Button
            size="sm"
            className={`bg-green-600 hover:bg-green-700 text-white gap-1 ${compact ? "text-xs h-7 px-1" : "text-xs"}`}
            onClick={() => openDialog(schedule, "completed")}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            حضور
          </Button>
          <Button
            size="sm"
            variant="outline"
            className={`text-orange-600 border-orange-300 hover:bg-orange-50 dark:border-orange-800 dark:hover:bg-orange-950 ${compact ? "text-xs h-7 px-1" : "text-xs"}`}
            onClick={() => openDialog(schedule, "postponed")}
          >
            <CalendarClock className="w-3 h-3 ml-0.5" />
            تأجيل
          </Button>
          <Button
            size="sm"
            variant="outline"
            className={`text-red-600 border-red-300 hover:bg-red-50 dark:border-red-800 dark:hover:bg-red-950 ${compact ? "text-xs h-7 px-1" : "text-xs"}`}
            onClick={() => openDialog(schedule, "absent")}
          >
            <XCircle className="w-3 h-3 ml-0.5" />
            غياب
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">حصصي</h2>
        <p className="text-muted-foreground">متابعة طلابك وتسجيل الحضور أو الغياب.</p>
      </div>

      {/* TODAY SECTION */}
      <section className="space-y-4">
        <div className="flex items-center gap-3">
          <CalendarClock className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-bold text-primary">
            حصص اليوم — {daysArabic[today]}
          </h3>
          {todaySchedules.length > 0 && (
            <Badge className="bg-primary/10 text-primary border-primary/20">
              {todaySchedules.length} حصة
            </Badge>
          )}
        </div>

        {todaySchedules.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="py-10 text-center text-muted-foreground">
              لا يوجد حصص مجدولة اليوم 🌙
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {todaySchedules.map(schedule => (
              <SessionCard key={schedule.id} schedule={schedule} />
            ))}
          </div>
        )}
      </section>

      {/* REST OF WEEK */}
      {Object.keys(groupedOther).length > 0 && (
        <section className="space-y-4">
          <h3 className="text-base font-semibold text-muted-foreground border-b pb-2">بقية الجدول الأسبوعي</h3>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {otherDayOrder.filter(day => groupedOther[day]).map(day => (
              <div key={day} className="space-y-3">
                <h4 className="font-semibold text-sm text-muted-foreground">{daysArabic[day]}</h4>
                <div className="space-y-2">
                  {groupedOther[day]
                    .sort((a, b) => a.startTime.localeCompare(b.startTime))
                    .map(schedule => (
                    <SessionCard key={schedule.id} schedule={schedule} compact />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ACTION DIALOG */}
      <Dialog open={!!activeLogDialog} onOpenChange={(open) => !open && setActiveLogDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {activeLogDialog?.status === "completed" && "تسجيل حضور حصة ✅"}
              {activeLogDialog?.status === "postponed" && "تأجيل حصة 📅"}
              {activeLogDialog?.status === "absent" && "تسجيل غياب ❌"}
            </DialogTitle>
            <DialogDescription>
              للطالب: <span className="font-semibold text-foreground">{activeLogDialog?.studentName}</span>
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            {activeLogDialog?.status === "absent" && (
              <div className="rounded-xl border border-red-200 bg-red-50/70 p-3 dark:border-red-900 dark:bg-red-950/20">
                <p className="text-sm text-red-700 dark:text-red-300">
                  سيتم تسجيل غياب الطالب <strong>بدون خصم</strong> من رصيد الحصص.
                </p>
              </div>
            )}

            {activeLogDialog?.status === "postponed" && (
              <div className="grid gap-4 rounded-xl border bg-orange-50/70 p-4 dark:bg-orange-950/20">
                <p className="text-sm font-semibold text-orange-800 dark:text-orange-200">اختر الموعد الجديد للحصة</p>
                <div className="grid gap-2">
                  <Label>اليوم الجديد</Label>
                  <Select value={rescheduleData.dayOfWeek} onValueChange={(val: DayOfWeek) => setRescheduleData({ ...rescheduleData, dayOfWeek: val })}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر اليوم" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(daysArabic).map(([key, label]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="new-time">الوقت الجديد</Label>
                  <Input
                    id="new-time"
                    type="time"
                    value={rescheduleData.startTime}
                    onChange={e => setRescheduleData({ ...rescheduleData, startTime: e.target.value })}
                  />
                </div>
              </div>
            )}

            <div className="grid gap-2">
              <Label htmlFor="notes">ملاحظات (اختياري)</Label>
              <Input
                id="notes"
                placeholder="أضف ملاحظات..."
                value={notes}
                onChange={e => setNotes(e.target.value)}
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              onClick={handleLogSubmit}
              disabled={createLog.isPending}
              className={
                activeLogDialog?.status === "completed" ? "bg-green-600 hover:bg-green-700" :
                activeLogDialog?.status === "postponed" ? "bg-orange-600 hover:bg-orange-700" :
                "bg-red-600 hover:bg-red-700"
              }
            >
              {createLog.isPending && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
              تأكيد
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
