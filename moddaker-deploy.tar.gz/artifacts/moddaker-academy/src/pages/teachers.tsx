import { useState } from "react";
import { 
  useListTeachers, 
  getListTeachersQueryKey,
  useCreateTeacher,
  useUpdateTeacher,
  useDeleteTeacher,
  useGetCurrentProfile,
  getGetCurrentProfileQueryKey
} from "@workspace/api-client-react";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, Plus, Edit2, Trash2, MoreHorizontal } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/utils";

export default function Teachers() {
  const { toast } = useToast();
  const { data: teachers, isLoading } = useListTeachers({
    query: { queryKey: getListTeachersQueryKey() }
  });
  const { data: profile } = useGetCurrentProfile({
    query: { queryKey: getGetCurrentProfileQueryKey() }
  });
  const isAdmin = profile?.role === "admin";

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [createData, setCreateData] = useState({ name: "", email: "", phone: "", sessionRate: 0 });
  const createTeacher = useCreateTeacher({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListTeachersQueryKey() });
        setIsCreateOpen(false);
        setCreateData({ name: "", email: "", phone: "", sessionRate: 0 });
        toast({ title: "تم الإضافة بنجاح", description: "تم إضافة المعلم بنجاح" });
      }
    }
  });

  const [editTeacherId, setEditTeacherId] = useState<number | null>(null);
  const [editData, setEditData] = useState({ name: "", email: "", phone: "", sessionRate: 0, active: true });
  const updateTeacher = useUpdateTeacher({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListTeachersQueryKey() });
        setEditTeacherId(null);
        toast({ title: "تم التحديث بنجاح", description: "تم تحديث بيانات المعلم بنجاح" });
      }
    }
  });

  const deleteTeacher = useDeleteTeacher({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListTeachersQueryKey() });
        toast({ title: "تم الحذف بنجاح", description: "تم حذف المعلم بنجاح" });
      }
    }
  });

  const openEdit = (teacher: any) => {
    setEditTeacherId(teacher.id);
    setEditData({
      name: teacher.name,
      email: teacher.email,
      phone: teacher.phone || "",
      sessionRate: teacher.sessionRate,
      active: teacher.active
    });
  };

  const handleCreate = () => {
    createTeacher.mutate({
      data: {
        name: createData.name,
        email: createData.email,
        phone: createData.phone,
        sessionRate: createData.sessionRate
      }
    });
  };

  const handleEdit = () => {
    if (editTeacherId) {
      updateTeacher.mutate({
        id: editTeacherId,
        data: {
          name: editData.name,
          email: editData.email,
          phone: editData.phone,
          sessionRate: editData.sessionRate,
          active: editData.active
        }
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">المعلمين</h2>
          <p className="text-muted-foreground">إدارة المعلمين وتحديد أجر الحصة.</p>
        </div>
        
        {isAdmin && <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              إضافة معلم
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>إضافة معلم جديد</DialogTitle>
              <DialogDescription>أدخل بيانات المعلم الأساسية.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">الاسم</Label>
                <Input 
                  id="name" 
                  value={createData.name}
                  onChange={e => setCreateData({ ...createData, name: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="email">البريد الإلكتروني</Label>
                <Input 
                  id="email" 
                  type="email"
                  value={createData.email}
                  onChange={e => setCreateData({ ...createData, email: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="phone">رقم الهاتف</Label>
                <Input 
                  id="phone" 
                  value={createData.phone}
                  onChange={e => setCreateData({ ...createData, phone: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="rate">أجر الحصة</Label>
                <Input 
                  id="rate" 
                  type="number"
                  value={createData.sessionRate}
                  onChange={e => setCreateData({ ...createData, sessionRate: Number(e.target.value) })}
                />
              </div>
            </div>
            <DialogFooter>
              <Button 
                onClick={handleCreate} 
                disabled={createTeacher.isPending || !createData.name || !createData.email}
              >
                {createTeacher.isPending && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
                إضافة
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>}
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-right">الاسم</TableHead>
              <TableHead className="text-right">البريد</TableHead>
              <TableHead className="text-right">الهاتف</TableHead>
              <TableHead className="text-right">أجر الحصة</TableHead>
              <TableHead className="text-right">الحالة</TableHead>
              {isAdmin && <TableHead className="text-right w-[100px]">إجراءات</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {teachers?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                  لا يوجد معلمين مسجلين
                </TableCell>
              </TableRow>
            ) : (
              teachers?.map((teacher) => (
                <TableRow key={teacher.id}>
                  <TableCell className="font-medium">{teacher.name}</TableCell>
                  <TableCell>{teacher.email}</TableCell>
                  <TableCell>{teacher.phone || "-"}</TableCell>
                  <TableCell>{formatCurrency(teacher.sessionRate)}</TableCell>
                  {isAdmin && <TableCell>
                    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                      teacher.active ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-500' : 'bg-muted text-muted-foreground'
                    }`}>
                      {teacher.active ? "نشط" : "غير نشط"}
                    </span>
                  </TableCell>}
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>إجراءات</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => openEdit(teacher)} className="gap-2">
                          <Edit2 className="h-4 w-4" /> تعديل
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                          className="text-destructive focus:text-destructive gap-2"
                          onClick={() => {
                            if(confirm('هل أنت متأكد من حذف هذا المعلم؟')) {
                              deleteTeacher.mutate({ id: teacher.id });
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" /> حذف
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={!!editTeacherId} onOpenChange={(open) => !open && setEditTeacherId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تعديل بيانات المعلم</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-name">الاسم</Label>
              <Input 
                id="edit-name" 
                value={editData.name}
                onChange={e => setEditData({ ...editData, name: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-email">البريد الإلكتروني</Label>
              <Input 
                id="edit-email" 
                type="email"
                value={editData.email}
                onChange={e => setEditData({ ...editData, email: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-phone">رقم الهاتف</Label>
              <Input 
                id="edit-phone" 
                value={editData.phone}
                onChange={e => setEditData({ ...editData, phone: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-rate">أجر الحصة</Label>
              <Input 
                id="edit-rate" 
                type="number"
                value={editData.sessionRate}
                onChange={e => setEditData({ ...editData, sessionRate: Number(e.target.value) })}
              />
            </div>
            <div className="flex items-center gap-2 mt-2">
              <input 
                type="checkbox" 
                id="edit-active" 
                checked={editData.active}
                onChange={e => setEditData({ ...editData, active: e.target.checked })}
                className="rounded border-input text-primary focus:ring-primary h-4 w-4"
              />
              <Label htmlFor="edit-active" className="cursor-pointer">حساب نشط</Label>
            </div>
          </div>
          <DialogFooter>
            <Button 
              onClick={handleEdit} 
              disabled={updateTeacher.isPending || !editData.name || !editData.email}
            >
              {updateTeacher.isPending && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
              تحديث
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
