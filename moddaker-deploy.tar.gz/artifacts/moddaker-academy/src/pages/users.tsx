import { useState } from "react";
import { 
  useListProfiles, 
  getListProfilesQueryKey,
  useListTeachers,
  getListTeachersQueryKey
} from "@workspace/api-client-react";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, Plus, UserCog, Shield, GraduationCap } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

const roleLabels: Record<string, { label: string; variant: "default" | "secondary" | "outline" }> = {
  admin: { label: "مدير", variant: "default" },
  supervisor: { label: "مشرف", variant: "secondary" },
  teacher: { label: "معلم", variant: "outline" },
};

type NewUserData = {
  name: string;
  email: string;
  password: string;
  role: string;
  teacherId: string;
};

export default function UsersPage() {
  const { toast } = useToast();
  const { data: profiles, isLoading } = useListProfiles({
    query: { queryKey: getListProfilesQueryKey() }
  });
  const { data: teachers } = useListTeachers({
    query: { queryKey: getListTeachersQueryKey() }
  });

  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState<NewUserData>({
    name: "",
    email: "",
    password: "",
    role: "teacher",
    teacherId: "",
  });

  const set = (field: keyof NewUserData) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setFormData(prev => ({ ...prev, [field]: e.target.value }));

  const handleCreate = async () => {
    if (!formData.name || !formData.email || !formData.password || !formData.role) {
      toast({ title: "تعبئة البيانات", description: "يرجى ملء جميع الحقول المطلوبة.", variant: "destructive" });
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch(`${import.meta.env.BASE_URL}api/academy/users`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          password: formData.password,
          role: formData.role,
          teacherId: formData.teacherId ? Number(formData.teacherId) : undefined,
        }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.error || "فشل إنشاء الحساب");
      }
      await queryClient.invalidateQueries({ queryKey: getListProfilesQueryKey() });
      setDialogOpen(false);
      setFormData({ name: "", email: "", password: "", role: "teacher", teacherId: "" });
      toast({ title: "تم إنشاء الحساب بنجاح ✅" });
    } catch (err: any) {
      toast({ title: "خطأ", description: err?.message || "تعذر إنشاء الحساب", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">إدارة المستخدمين</h2>
          <p className="text-muted-foreground">إنشاء وإدارة حسابات المعلمين والمشرفين.</p>
        </div>
        <Button className="gap-2 self-start" onClick={() => setDialogOpen(true)}>
          <Plus className="h-4 w-4" />
          إضافة مستخدم
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي المستخدمين</CardTitle>
            <UserCog className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{profiles?.length ?? 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">المديرين</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{profiles?.filter(p => p.role === "admin").length ?? 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">المعلمين</CardTitle>
            <GraduationCap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{profiles?.filter(p => p.role === "teacher").length ?? 0}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-right">الاسم</TableHead>
              <TableHead className="text-right">البريد الإلكتروني</TableHead>
              <TableHead className="text-right">الدور</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {profiles?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={3} className="text-center py-8 text-muted-foreground">
                  لا يوجد مستخدمين بعد
                </TableCell>
              </TableRow>
            ) : (
              profiles?.map(profile => {
                const roleInfo = roleLabels[profile.role] ?? { label: profile.role, variant: "outline" as const };
                return (
                  <TableRow key={profile.id}>
                    <TableCell className="font-medium">{profile.name}</TableCell>
                    <TableCell className="text-muted-foreground">{profile.email}</TableCell>
                    <TableCell>
                      <Badge variant={roleInfo.variant}>{roleInfo.label}</Badge>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>إضافة مستخدم جديد</DialogTitle>
            <DialogDescription>سيتم إنشاء حساب دخول للمستخدم بالبريد الإلكتروني وكلمة المرور.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="u-name">الاسم الكامل *</Label>
              <Input id="u-name" value={formData.name} onChange={set("name")} placeholder="اسم المعلم أو المشرف" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="u-email">البريد الإلكتروني *</Label>
              <Input id="u-email" type="email" value={formData.email} onChange={set("email")} placeholder="example@email.com" dir="ltr" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="u-password">كلمة المرور *</Label>
              <Input id="u-password" type="password" value={formData.password} onChange={set("password")} placeholder="8 أحرف على الأقل" />
            </div>
            <div className="grid gap-2">
              <Label>الدور *</Label>
              <Select value={formData.role} onValueChange={v => setFormData(p => ({ ...p, role: v, teacherId: "" }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="teacher">معلم</SelectItem>
                  <SelectItem value="supervisor">مشرف</SelectItem>
                  <SelectItem value="admin">مدير</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {formData.role === "teacher" && (
              <div className="grid gap-2">
                <Label>ربط بسجل معلم (اختياري)</Label>
                <Select value={formData.teacherId} onValueChange={v => setFormData(p => ({ ...p, teacherId: v }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر المعلم..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">— بدون ربط —</SelectItem>
                    {teachers?.map(t => (
                      <SelectItem key={t.id} value={String(t.id)}>{t.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button onClick={handleCreate} disabled={submitting}>
              {submitting && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
              إنشاء الحساب
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
